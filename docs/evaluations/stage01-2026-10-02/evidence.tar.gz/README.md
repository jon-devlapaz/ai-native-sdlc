# Stage 01 evaluation record — 2026-10-02

Start with reports/results.md. It links all twelve answers and their original judgments inside this archive. Next-session guidance is in repository/docs/evaluations/stage01-2026-10-02/README.md.

Decision: no reliable benefit demonstrated; keep current workflow guidance. This is four synthetic cases with one sample per version, not a completed issue #37 or proof of production quality. Automated judgments are uncalibrated and disputed.

runtime/run-2/: completed corrected run, twelve answers and twelve usable judgments.
runtime/run-1/: seven reused answers, six invalid completed judgments, one interrupted judge turn; read INVALID-JUDGING.md.
runtime/*failure*/ and *.log: retained setup failures and logs.
runtime/package-lock.json: pinned dependency tree; installed packages are excluded.
mechanical/: eight existing safeguard checks and package-check receipts.
repository/: research, conclusions, task criteria, instructions, configuration, and runner.
superseded-*/: unexecuted older plans; proposed human labels were never approved.

31 native provider turns started, 30 completed; native runtimes can make auxiliary requests. No authentication state or installed dependencies is included. Re-running needs authenticated native CLIs and path adjustments, and cannot guarantee identical outputs or backend model versions. Reading or reassessing the saved answers needs no new generation.

File hashes in manifest.json detect byte changes; they do not establish approval or judgment correctness. Original machine-local links remain in untouched repository snapshots; use the portable report for reviewing answers on another machine.
